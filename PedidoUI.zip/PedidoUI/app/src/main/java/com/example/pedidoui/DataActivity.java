package com.example.pedidoui;

import android.content.Intent;
import android.os.Bundle;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

public class DataActivity extends AppCompatActivity  implements AdapterView.OnItemSelectedListener {
    private EditText name;
    private EditText address;
    private EditText phone;
    private int solo;
    private int leche;
    private int cortado;
    private String dia;
    private String hora;
    private String tipoEntrega;
    private String tipoTelefono;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        name = findViewById(R.id.editName);
        address = findViewById(R.id.editAdress);
        phone = findViewById(R.id.editPhone);

        Intent intent = getIntent();
        cortado = intent.getIntExtra(MainActivity.CORTADO, 0);
        solo = intent.getIntExtra(MainActivity.SOLO, 0);
        leche = intent.getIntExtra(MainActivity.LECHE, 0);
        hora = intent.getStringExtra(OrderActivity.HORA);
        dia = intent.getStringExtra(OrderActivity.DIA);
        tipoEntrega = intent.getStringExtra(OrderActivity.TIPOENTREGA);

        String[] arraySpinner = new String[] {
                "Casa", "Trabajo", "Móvil", "Otro"
        };
        Spinner s = (Spinner) findViewById(R.id.Spinner);
        s.setOnItemSelectedListener(this);
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_item, arraySpinner);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        s.setAdapter(adapter);


    }
        @Override
        public boolean onCreateOptionsMenu(Menu menu) {
            // Inflate the menu; this adds items to the action bar if it is present.
            getMenuInflater().inflate(R.menu.menu_data, menu);
            return true;
        }
    public void confirmar(MenuItem item) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage("¿Está seguro que quiere hacer el pedido?")
                .setPositiveButton("Sí", (dialog, id) -> sendEmail())
                .setNegativeButton("No", (dialog, id) -> showToast())
                .create()
                .show();
    }

    private void showToast() {
        Toast.makeText(this, "Revisa el pedido", Toast.LENGTH_LONG).show();
    }
    private void sendEmail() {
        Intent intent = new Intent(Intent.ACTION_SEND);
        String nombre = name.getText().toString();
        String direccion = address.getText().toString();
        String telefono = phone.getText().toString();
        String subject = String.format("Pedido de "+ nombre);
        String body = String.format(
                "Mi pedido es:\n" +leche+
                        " cafes con leche\n" +solo+
                        " cafes solos\n" +cortado+
                        " cafes cortados\nLa fecha de entrega es "+dia+
                        " y la hora de entrega es " +hora+
                        " \n Modo de entrega: " +tipoEntrega+
                        " \n Dirección: "+direccion+
                        " \n Número de teléfono: "+telefono+" ("+tipoTelefono+")");
        intent.setType("*/*");
        intent.putExtra(Intent.EXTRA_EMAIL, "pedidos@mitienda.com");
        intent.putExtra(Intent.EXTRA_SUBJECT, subject);
        intent.putExtra(Intent.EXTRA_TEXT, body);
        if (intent.resolveActivity(getPackageManager()) != null) {
            startActivity(intent);
        }
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        tipoTelefono = parent.getItemAtPosition(position).toString();

    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }
}