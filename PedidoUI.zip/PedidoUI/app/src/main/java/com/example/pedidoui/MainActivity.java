package com.example.pedidoui;

import android.content.Intent;
import android.os.Bundle;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.view.View;

import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    public static final String SOLO ="solo";
    public static final String LECHE = "leche";
    public static final String CORTADO = "cortado" ;
    TextView valueSolo;
    int counterSolo=0;
    TextView valueLeche;
    int counterLeche=0;
    TextView valueCortado;
    int counterCortado=0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        valueSolo= (TextView) findViewById(R.id.countSolo);
        valueLeche= (TextView) findViewById(R.id.countLeche);
        valueCortado= (TextView) findViewById(R.id.countCortado);


    }

    public void soloIn(View view){
        counterSolo++;
        valueSolo.setText(Integer.toString(counterSolo));
    }

    public void  soloDe(View view){
        if (counterSolo>0){
            counterSolo--;
            valueSolo.setText(Integer.toString(counterSolo));
        }
    }

    public void lecheIn(View view){
        counterLeche++;
        valueLeche.setText(Integer.toString(counterLeche));
    }

    public void  lecheDe(View view){
        if (counterLeche>0){
            counterLeche--;
            valueLeche.setText(Integer.toString(counterLeche));
        }
    }

    public void cortadoIn(View view){
        counterCortado++;
        valueCortado.setText(Integer.toString(counterCortado));
    }

    public void  cortadoDe(View view){
        if (counterCortado>0){
            counterCortado--;
            valueCortado.setText(Integer.toString(counterCortado));
        }
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }


    public void resetCafes(MenuItem item) {
        valueSolo.setText(Integer.toString(0));
        valueLeche.setText(Integer.toString(0));
        valueCortado.setText(Integer.toString(0));
    }



        public void order(MenuItem item){
            Intent intent = new Intent(this, OrderActivity.class);
            intent.putExtra(CORTADO, counterSolo);
            intent.putExtra(SOLO, counterCortado);
            intent.putExtra(LECHE, counterLeche);
            startActivity(intent);
        }
}