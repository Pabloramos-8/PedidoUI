package com.example.pedidoui;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.os.Bundle;


import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Calendar;

public class OrderActivity extends AppCompatActivity {


    public static final String HORA = "hora";
    public static final String DIA = "dia";
    public static final String TIPOENTREGA = "tipoEntrega";
    private int solo;
    private int leche;
    private int cortado;
    private String dia;
    private String hora;
    private RadioButton domicilio;
    private RadioButton enLocal;
    TextView diaTextView;
    TextView horaTextView;
    private String tipoEntrega;
    @Override
    protected  void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        Intent intent = getIntent();

        domicilio = (RadioButton) findViewById(R.id.domicilio);
        enLocal = (RadioButton) findViewById(R.id.enLocal);

        cortado = intent.getIntExtra(MainActivity.CORTADO, 0);
        solo = intent.getIntExtra(MainActivity.SOLO, 0);
        leche = intent.getIntExtra(MainActivity.LECHE, 0);


        diaTextView = findViewById(R.id.dia);
        final Calendar cldr = Calendar.getInstance();
        int day_now = cldr.get(Calendar.DAY_OF_MONTH);
        int month_now = cldr.get(Calendar.MONTH);
        int year_now = cldr.get(Calendar.YEAR);
        guardarDia(day_now, month_now, year_now);
        diaTextView.setOnClickListener(v -> {
            DatePickerDialog picker = new DatePickerDialog(OrderActivity.this,
                    (view, year, month, day) -> guardarDia(day, month, year), year_now, month_now, day_now);
            picker.show();
        });

        horaTextView = findViewById(R.id.hora);
        int hour_now = cldr.get(Calendar.HOUR_OF_DAY);
        int min_now = cldr.get(Calendar.MINUTE);
        guardarHora(hour_now, min_now);
        horaTextView.setOnClickListener(v -> {
            TimePickerDialog picker = new TimePickerDialog(OrderActivity.this,
                    (view, hour, min) -> guardarHora(hour, min), hour_now, min_now, true);
            picker.show();
        });

    }

    public void onRadioButtonClicked(View view){
        if (((RadioButton) view).isChecked())
            switch(view.getId()) {
                case R.id.domicilio:
                    tipoEntrega = "A domicilio";
                    break;
                case R.id.enLocal:
                    tipoEntrega="En local";
                    break;
            }
    }

    private void guardarHora(int hour, int min) {
        hora = min < 10 ? String.format("%d:0%d", hour, min)
                : String.format("%d:%d", hour, min);
        horaTextView.setText(hora);
    }

    private void guardarDia(int day, int month, int year) {
        dia = String.format("%d/%d/%d", day, month + 1, year);
        diaTextView.setText(dia);
    }


        @Override
        public boolean onCreateOptionsMenu(Menu menu) {
            // Inflate the menu; this adds items to the action bar if it is present.
            getMenuInflater().inflate(R.menu.menu_order, menu);
            return true;
        }



    public void datos(MenuItem item){
        if (tipoEntrega == null){
            Toast.makeText(this, "No has seleccionado Modo de Entrega", Toast.LENGTH_LONG).show();

        }
        else {
            Intent intent = new Intent(this, DataActivity.class);
            intent.putExtra(MainActivity.CORTADO, cortado);
            intent.putExtra(MainActivity.SOLO, solo);
            intent.putExtra(MainActivity.LECHE, leche);
            intent.putExtra(HORA, hora);
            intent.putExtra(DIA, dia);
            intent.putExtra(TIPOENTREGA, tipoEntrega);
            startActivity(intent);
        }
    }

}